/**
 */
public class WelcomeCheckstyle 
{
   /**
    * Prints to std output.
    *
    * @param args Command line arguments (not used).
    */
   public static void main(String[] args) {
     
      System.out.println("Experience with Checkstyle!");
   
   }
}